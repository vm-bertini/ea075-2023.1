# EA075 - Introdução a Projeto de Sistemas Embarcados

## 1: Abrir o Kicad 7.0

## 2: Clique em Open File

## 3: Abrir o arquivo "Maze_Mapper.kicad_pro" dentro da pasta